For the groundtruth in the 'gt' folder, the corresponding class of different pixel value. 
  Pixel =   0, 	Background
  Pixel =  70, 	Road
  Pixel = 255, 	Car


The dataset also has been divided into 4 different traffic status (Empty, Fluid, Heavy and Jam).
The corresponding image index is:
  1 ~ 100: Empty
101 ~ 200: Heavy
201 ~ 300: Jam
301 ~ 400: Fluid	